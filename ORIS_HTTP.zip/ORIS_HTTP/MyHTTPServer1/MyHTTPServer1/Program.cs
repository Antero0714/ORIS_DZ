﻿using System;

namespace HttpServer
{
    class Program
    {
        //чтобы паблик считывал
        //Убрать абсолютный путь в папке public
        //открывать сайт по пути localhost: 8888/index.html
        //открывать любой  файл в папке localhost:8888/images/test.webbp
        //необходимо определять тип файла и подставлять соответствующий content type
        //      автоматически проставлять content-type -> если картинка webp то писать aplication javascript
        // если локалхост то открываем по умолчанию index.html, а если нет, то говорить, что не найден html
        //почта яндекс почта гугл почта mail
        //паттерн проектирования

        static void Main(string[] args)
        {
            HttpServer server = new HttpServer();
            server.Start();

            Console.WriteLine("Нажми Enter чтобы остановить сервер");
            Console.ReadLine();

            server.Stop();
        }
    }
}
