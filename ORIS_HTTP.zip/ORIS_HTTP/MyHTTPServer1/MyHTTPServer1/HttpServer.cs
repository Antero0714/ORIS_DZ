﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HttpServer
{
    public class HttpServer
    {
        public int Port = 8888;
        private HttpListener _listener;
        private Stopwatch _stopwatch;
        private bool _isRunning;
        private int _requestCount;

        public void Start()
        {
            string publicFolderPath = "C:\\Users\\andre\\Documents\\VS Repos\\repos\\MyHTTPServer1\\MyHTTPServer1\\public\\";
            if (!Directory.Exists(publicFolderPath))
            {
                Console.WriteLine("Папка Public not found");
                return;
            }

            _listener = new HttpListener();
            _listener.Prefixes.Add($"http://127.0.0.1:{Port}/");
            Console.WriteLine("Сервер запущен...");
            _listener.Start();
            _stopwatch = Stopwatch.StartNew();
            _isRunning = true;
            Receive();
        }

        public void Stop()
        {
            _isRunning = false;
            _listener.Stop();
            _stopwatch.Stop();
            Console.WriteLine("Сервер остановлен.");
            Console.WriteLine($"Сервер работал: {_stopwatch.Elapsed.TotalSeconds} секунд.");
        }

        private async void Receive()
        {
            while (_isRunning)
            {
                try
                {
                    var context = await _listener.GetContextAsync();
                    await ProcessRequest(context);
                }
                catch (HttpListenerException)
                {
                    if (!_isRunning) break;
                }
            }
        }

        private async Task ProcessRequest(HttpListenerContext context)
        {
            HttpListenerRequest reqest = context.Request;
            var response = context.Response;
            _requestCount++;  // Увеличиваем количество запросов

            string filePath = Path.Combine("C:\\Users\\andre\\Documents\\VS Repos\\repos\\MyHTTPServer1\\MyHTTPServer1\\public", reqest.Url.AbsolutePath.TrimStart('/'));

            // Если URL пустой или указывает на корень, используем index.html
            if (string.IsNullOrEmpty(reqest.Url.AbsolutePath) || reqest.Url.AbsolutePath == "/")
            {
                filePath = Path.Combine("C:\\Users\\andre\\Documents\\VS Repos\\repos\\MyHTTPServer1\\MyHTTPServer1\\public", "index.html");
            }
            else if (reqest.Url.AbsolutePath == "/status")
            {
                // Обработка запроса на статус сервера
                await ReturnServerStatus(context);
                return; // Завершаем метод, чтобы не обрабатывать его как файл
            }

            // Проверяем наличие файла
            if (File.Exists(filePath))
            {
                string contentType = GetContentType(filePath);
                response.ContentType = contentType;

                byte[] buffer = await File.ReadAllBytesAsync(filePath);
                response.ContentLength64 = buffer.Length;

                using (Stream output = response.OutputStream)
                {
                    await output.WriteAsync(buffer, 0, buffer.Length);
                }
            }
            else
            {
                // Файл не найден - возвращаем 404
                response.StatusCode = (int)HttpStatusCode.NotFound;
                string errorMessage = "404: Файл не найден.";
                byte[] buffer = Encoding.UTF8.GetBytes(errorMessage);
                response.ContentLength64 = buffer.Length;
                response.ContentType = "text/plain; charset=utf-8";

                using (Stream output = response.OutputStream)
                {
                    await output.WriteAsync(buffer, 0, buffer.Length);
                }
            }
        }

        private async Task ReturnServerStatus(HttpListenerContext context)
        {
            var response = context.Response;

            // Создаем информацию о состоянии сервера
            string statusInfo = $"Сервер работает в течение: {_stopwatch.Elapsed.TotalSeconds:F2} секунд\n" +
                                $"Общее количество запросов: {_requestCount}";

            byte[] buffer = Encoding.UTF8.GetBytes(statusInfo);
            response.ContentLength64 = buffer.Length;
            response.ContentType = "text/plain; charset=utf-8";

            using (Stream output = response.OutputStream)
            {
                await output.WriteAsync(buffer, 0, buffer.Length);
            }
        }

        private string GetContentType(string filePath)
        {
            string extension = Path.GetExtension(filePath).ToLowerInvariant();
            return extension switch
            {
                ".html" => "text/html",
                ".css" => "text/css",
                ".js" => "application/javascript",
                ".png" => "image/png",
                ".gif" => "image/gif",
                ".svg" => "image/svg+xml",
                ".webp" => "image/webp",
                _ => "application/octet-stream",
            };
        }
    }

   
}
