﻿using System.Net.Mail;
using System.Net;

namespace MyHttpServer.Services
{
    internal sealed class EmailService : IEmailService
    {

        // TODO: вынести настройки smtp сервера: домен/логин/ пароль  в config.json

        public void SendEmail(string email, string subject, string message)
        {
            string fromEmail = "somemail@gmail.com";

            // отправитель - устанавливаем адрес и отображаемое в письме имя
            MailAddress from = new MailAddress(fromEmail, "Tom");

            // кому отправляем
            MailAddress to = new MailAddress(email);

            // создаем объект сообщения
            MailMessage m = new MailMessage(from, to);

            // тема письма
            m.Subject = subject;

            // текст письма
            m.Body = message;

            // письмо представляет код html
            m.IsBodyHtml = true;

            // адрес smtp-сервера и порт, с которого будем отправлять письмо
            SmtpClient smtp = new SmtpClient("smtp.yandex.ru", 465);

            // логин и пароль
            smtp.Credentials = new NetworkCredential(fromEmail, "mypassword");
            smtp.EnableSsl = true;
            smtp.Send(m);
        }
    }
}
