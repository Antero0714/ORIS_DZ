﻿namespace MyHttpServer.Services
{
    internal interface IEmailService
    {
        void SendEmail(string email, string title, string message);
    }
}
